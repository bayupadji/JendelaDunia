<?php $__env->startSection('title', 'Shop'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        

        <div class="container" id="Trend" data-aos="zoom-out" data-aos-duration="1000">

            <div class="row" style="margin-top: 4em;">
                <div class="col-md-3">
                    <div class="card-sl">
                        <div class="card-image">
                            <img
                                src="https://images.pexels.com/photos/1149831/pexels-photo-1149831.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" />
                        </div>
                        <div class="card-heading">
                            Audi Q8
                        </div>
                        <div class="card-text">
                            Audi Q8 is a full-size luxury crossover SUV coupé made by Audi that was launched in 2018.
                        </div>
                        <div class="card-text price">
                            $67,400
                        </div>
                        <a href="Detailbrg" class="card-button "> Detail</a>
                    </div>

                </div>

                <div class="col-md-3">
                    <div class="card-sl">
                        <div class="card-image">
                            <img
                                src="https://images.pexels.com/photos/1149831/pexels-photo-1149831.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" />
                        </div>
                        <div class="card-heading">
                            Audi Q8
                        </div>
                        <div class="card-text">
                            Audi Q8 is a full-size luxury crossover SUV coupé made by Audi that was launched in 2018.
                        </div>
                        <div class="card-text price">
                            $67,400
                        </div>
                        <a href="#" class="card-button "> Detail</a>
                    </div>

                </div>

                <div class="col-md-3">
                    <div class="card-sl">
                        <div class="card-image">
                            <img
                                src="https://images.pexels.com/photos/1149831/pexels-photo-1149831.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" />
                        </div>
                        <div class="card-heading">
                            Audi Q8
                        </div>
                        <div class="card-text">
                            Audi Q8 is a full-size luxury crossover SUV coupé made by Audi that was launched in 2018.
                        </div>
                        <div class="card-text price">
                            $67,400
                        </div>
                        <a href="#" class="card-button "> Detail</a>
                    </div>

                </div>

                <div class="col-md-3">
                    <div class="card-sl">
                        <div class="card-image">
                            <img
                                src="https://images.pexels.com/photos/1149831/pexels-photo-1149831.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" />
                        </div>
                        <div class="card-heading">
                            Audi Q8
                        </div>
                        <div class="card-text">
                            Audi Q8 is a full-size luxury crossover SUV coupé made by Audi that was launched in 2018.
                        </div>
                        <div class="card-text price">
                            $67,400
                        </div>
                        <a href="#" class="card-button "> Detail</a>
                    </div>

                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\bayup\Downloads\teslaravel\teslaravel\resources\views/Content/Shop.blade.php ENDPATH**/ ?>