<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!--bootstrap-->
    <link rel="stylesheet" href="{{ asset('/Style/style.css') }}">
    <link rel="stylesheet" href="{{ asset('/resources/css/styles.css') }}">
    <link rel="stylesheet" href="{{ asset('/Style/bootstrap.min.css') }}">


    <!--font-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter&family=Sora&display=swap" rel="stylesheet">


    <title>@yield('title')</title>
</head>

<body>
    <!-- navbar -->
    <nav class="navbar navbar-expand-lg py-3 navbar-light bg-light sticky-top">
        <div class="container">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo01"
                aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
                <a class="navbar-brand fw-bold" href="/"><img src="{{ URL::asset('/images/Logo.png') }}"></a>
                <form class="d-flex flex-fill justify-content-between ">
                    <input class="form-control me-2 search" type="search" placeholder="Search" aria-label="Search">
                </form>


                <div class="d-flex justify-content-end">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 p-1">
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="/">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="Shop#">Shop</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="Cart">Cart</a>
                        </li>

                        <li class="nav-item">
                            <a class="btn link" href="Login">Masuk</a>
                        </li>


                    </ul>
                </div>
            </div>
        </div>
    </nav>

    @yield('content')

    <footer class="footer">
        <div class="container">
            <div class="d-flex justify-content-center mt-3">
                <img src=" {{ URL::asset('/images/Logo.png') }}" class=>
            </div>
            <h5 class="text-center mt-3 fw-bold">Contact Us</h5>
            <div class="d-flex justify-content-center flex-lg-row gap-4">
                <div class="text-center">
                    <b>Email</b> JendelaDunia@gmail.com
                </div>
                <div class="text-center">
                    <b>No.Telp</b> 08574639201
                </div>
            </div>
            <h6 class="text-center mt-3 ">&copy Copyright 2021</h6>

        </div>
    </footer>

</body>

<script src="{{ asset('/Style/popper.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('/Style/bootstrap.bundle.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('/Style/bootstrap.bundle.js') }}" type="text/javascript"></script>
<script src="{{ asset('/style/bootstrap.min.js') }}" type="text/javascript"></script>


</html>
