<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="hero vh-100 d-flex align-items-center" id="home"
        style=" background-image: url('<?php echo e(asset('images/Hero.jpg')); ?>');">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 mx-auto text-center">
                    <h1 data-aos="zoom-in" data-aos-duration="1000" class="display-4 text-white"><img
                            src="<?php echo e(URL::asset('/images/Logo.png')); ?>" style="width:200px"></h1>
                    <p class="text-white my-3" data-aos="fade-up" data-aos-duration="1000">Lorem ipsum dolor sit amet,
                        consectetur adipisicing elit. Eaque quia sequi eius. Quas, totam aliquid. Repudiandae reiciendis vel
                        excepturi ipsa voluptate dicta!</p>

                    <div class="d-flex justify-content-center gap-2">
                        <a class="btn " href="Shop"> Shop Now</a>
                        <a class="btn cart" href="#About">About Us</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    

    <div class="container" id="About">
        <h3 class="judul text-center fw-bold" style="margin-Top: 4em ;margin-bottom: 2em;">About Us</h3>
        <P class="text-center"><b>Jendela Dunia</b> dibuat pada tahun 2021 sebagai salah satu solusi untuk menyegarkan
            pikiran
            anda ditengah wabah yang tengah bergulir di Indonesia saat ini. Kami akan terus bekerja dan berusaha untuk
            menyediakan buku – buku dengan kualitas terbaik bagi anda agar anda tetap betah untuk berada di dalam rumah.
            Dengan adanya Jendela Dunia anda tidak lagi perlu berpikir untuk pergi keluar demi mencari buku dan membeli
            buku, hanya dengan menggunakan gadget yang anda miliki, buku yang anda inginkan akan sampai didepan rumah anda.
        </P>
        <p class="text-center"><b>Jendela Dunia</b> memungkinkan anda untuk memilih ribuan jenis buku, baik internasional
            maupun
            nasional dengan sistem pengiriman yang cepat dan tentunya harga yang terjangkau. Jendela Dunia juga merupakan
            sebuah solusi bagi anda yang memiliki buku yang sudah tidak terpakai dirumah. Cukup dengan mengisi form yang
            disediakan, kami jamin gudang dan rumah anda akan terasa lebih longgar daripada sebelumnya. Anda bingung
            bagaimana cara mengirim buku yang anda jual? Tenang, cukup kirimkan alamat anda kepada kami, maka kami akan
            mendatangi rumah anda untuk menjemput buku yang ingin anda jual. Semua prosedur akan kami lakukan dengan
            protokol kesehatan yang ketat, jadi anda tidak perlu kuatir akan kesehatan anda.</p>

        <p></p>
    </div>

    

    <div class="container" id="Trend" data-aos="zoom-out" data-aos-duration="1000">
        <h3 class="judul text-center fw-bold" style="margin-Top: 4em; margin-bottom: 2em;">Trending</h3>

        <div class="row">
            <div class="col-md-3">
                <div class="card-sl">
                    <div class="card-image">
                        <img
                            src="https://images.pexels.com/photos/1149831/pexels-photo-1149831.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" />
                    </div>
                    <div class="card-heading">
                        Audi Q8
                    </div>
                    <div class="card-text price">
                        $67,400
                    </div>
                    <a href="#" class="card-button stretched-link"> Shop</a>
                </div>

            </div>

            <div class="col-md-3">
                <div class="card-sl">
                    <div class="card-image">
                        <img
                            src="https://images.pexels.com/photos/1149831/pexels-photo-1149831.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" />
                    </div>
                    <div class="card-heading">
                        Audi Q8
                    </div>
                    <div class="card-text price">
                        $67,400
                    </div>
                    <a href="#" class="card-button stretched-link"> Shop</a>
                </div>

            </div>

            <div class="col-md-3">
                <div class="card-sl">
                    <div class="card-image">
                        <img
                            src="https://images.pexels.com/photos/1149831/pexels-photo-1149831.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" />
                    </div>
                    <div class="card-heading">
                        Audi Q8
                    </div>
                    <div class="card-text price">
                        $67,400
                    </div>
                    <a href="#" class="card-button stretched-link"> Shop</a>
                </div>

            </div>

            <div class="col-md-3">
                <div class="card-sl">
                    <div class="card-image">
                        <img
                            src="https://images.pexels.com/photos/1149831/pexels-photo-1149831.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" />
                    </div>
                    <div class="card-heading">
                        Audi Q8
                    </div>
                    <div class="card-text price">
                        $67,400
                    </div>
                    <a href="#" class="card-button stretched-link"> Shop</a>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\bayup\Downloads\teslaravel\teslaravel\resources\views/Content/Home.blade.php ENDPATH**/ ?>