<?php $__env->startSection('title', 'Detail'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row" style="margin-top:4em;">
            <div class="col-sm-4">
                <img src="<?php echo e(URL::asset('/images/buku.jpeg')); ?>">
            </div>

            <div class="col">
                <h3>Nama Barang</h3>
                <p class="price">Rp.100.000</p>
                <p>Jenis Buku : Fiksi</p>
                <p>Bahasa : Bahasa Indonesia</p>
                <p>Penerbit : contoh penerbit</p>
                <p>Penulis : Tere liye</p>
                <p>Jumlah Halaman : 160 Lembar</p>
                <div class="row">
                    <div class="col-sm-2">
                        <a class="btn cart" href="">Keranjang</a>
                    </div>
                    <div class="col-sm">
                        <a class="btn" href="">Beli Sekarang</a>
                    </div>

                </div>
            </div>

            <div class="Deskripsi">
                <h4 class="fw-bold">Deskripsi Produk</h4>
                <p><b>SELENA dan NEBULA</b> adalah buku ke-8 dan ke-9 yang menceritakan siapa orangtua Raib dalam serial
                    petualangan dunia paralel. Dua buku ini sebaiknya dibaca berurutan. Kedua buku ini juga bercerita
                    tentang Akademi Bayangan Tingkat Tinggi, sekolah terbaik di seluruh Klan Bulan. Tentang persahabatan
                    tiga mahasiswa, yang diam-diam memiliki rencana bertualang ke tempat-tempat jauh. Tapi petualangan itu
                    berakhir buruk, saat persahabatan mereka diuji dengan rasa suka, egoisme, dan pengkhianatan. Ada banyak
                    karakter baru, tempat-tempat baru, juga sejarah dunia paralel yang diungkap. Di dua buku ini kalian akan
                    berkenalan dengan salah satu karakter paling kuat di dunia paralel sejauh ini. Tapi itu jika kalian bisa
                    menebaknya. Dua buku ini bukan akhir. Justru awal terbukanya kembali portal menuju Klan Aldebaran.</p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\teslaravel\resources\views/Content/Detailbrg.blade.php ENDPATH**/ ?>