<?php $__env->startSection('content'); ?>

    <body class="sb-nav-fixed">

        <div class="container">
            <main>
                <div class="container-fluid px-4 mt-3">
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                </div>
            </main>

            <div class="d-flex justify-content-center gap-3">
                <div class="card-dash">
                    <a class="Ladmin" href="User">
                        <h5>User</h5>
                        <h2>Jumlah User</h2>
                        <h6 class="fw-light">Last updated 3 mins ago</h6>
                    </a>
                </div>
                <div class="card-dash">
                    <a class="Ladmin" href="Barang">
                        <h5>Barang</h5>
                        <h2>Jumlah Barang</h2>
                        <h6 class="fw-light">Last updated 3 mins ago</h6>
                    </a>
                </div>
                <div class="card-dash">
                    <a class="Ladmin" href="Transaksi">
                        <h5>Transaksi</h5>
                        <h2>Jumlah Transaksi</h2>
                        <h6 class="fw-light">Last updated 3 mins ago</h6>
                    </a>
                </div>
            </div>
        </div>
    </body>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\bayup\Downloads\teslaravel\teslaravel\resources\views/Content/db.blade.php ENDPATH**/ ?>