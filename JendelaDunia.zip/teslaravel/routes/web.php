<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('Content/Home');
});

Route::get('Shop', function () {
    return view('Content/Shop');
});

Route::get('Checkout', function () {
    return view('Content/Checkout');
});

Route::get('Login', function () {
    return view('Content/Login');
});

Route::get('Register', function () {
    return view('Content/Register');
});

Route::get('Detailbrg', function () {
    return view('Content/Detailbrg');
});

Route::get('Cart', function () {
    return view('Content/Cart');
});

Route::get('db', function () {
    return view('Content/db');
});

Route::get('User', function () {
    return view('Admin/User');
});

Route::get('Barang', function () {
    return view('Admin/Barang');
});

Route::get('Transaksi', function () {
    return view('Admin/Transaksi');
});
