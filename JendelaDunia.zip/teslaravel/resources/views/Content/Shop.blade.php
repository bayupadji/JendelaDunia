@extends('Layout.index')

@section('title', 'Shop')

@section('content')
    <div class="container">
        {{-- <div class="row">
            <div class="col">
                <div class="card">

                </div>
            </div>
        </div> --}}

        <div class="container" id="Trend" data-aos="zoom-out" data-aos-duration="1000">

            <div class="row" style="margin-top: 4em;">
                <div class="col-md-3">
                    <div class="card-sl">
                        <div class="card-image">
                            <img
                                src="https://images.pexels.com/photos/1149831/pexels-photo-1149831.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" />
                        </div>
                        <div class="card-heading">
                            Audi Q8
                        </div>
                        <div class="card-text">
                            Audi Q8 is a full-size luxury crossover SUV coupé made by Audi that was launched in 2018.
                        </div>
                        <div class="card-text price">
                            $67,400
                        </div>
                        <a href="Detailbrg" class="card-button "> Detail</a>
                    </div>

                </div>

                <div class="col-md-3">
                    <div class="card-sl">
                        <div class="card-image">
                            <img
                                src="https://images.pexels.com/photos/1149831/pexels-photo-1149831.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" />
                        </div>
                        <div class="card-heading">
                            Audi Q8
                        </div>
                        <div class="card-text">
                            Audi Q8 is a full-size luxury crossover SUV coupé made by Audi that was launched in 2018.
                        </div>
                        <div class="card-text price">
                            $67,400
                        </div>
                        <a href="#" class="card-button "> Detail</a>
                    </div>

                </div>

                <div class="col-md-3">
                    <div class="card-sl">
                        <div class="card-image">
                            <img
                                src="https://images.pexels.com/photos/1149831/pexels-photo-1149831.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" />
                        </div>
                        <div class="card-heading">
                            Audi Q8
                        </div>
                        <div class="card-text">
                            Audi Q8 is a full-size luxury crossover SUV coupé made by Audi that was launched in 2018.
                        </div>
                        <div class="card-text price">
                            $67,400
                        </div>
                        <a href="#" class="card-button "> Detail</a>
                    </div>

                </div>

                <div class="col-md-3">
                    <div class="card-sl">
                        <div class="card-image">
                            <img
                                src="https://images.pexels.com/photos/1149831/pexels-photo-1149831.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" />
                        </div>
                        <div class="card-heading">
                            Audi Q8
                        </div>
                        <div class="card-text">
                            Audi Q8 is a full-size luxury crossover SUV coupé made by Audi that was launched in 2018.
                        </div>
                        <div class="card-text price">
                            $67,400
                        </div>
                        <a href="#" class="card-button "> Detail</a>
                    </div>

                </div>
            </div>

        </div>
    </div>
@endsection
