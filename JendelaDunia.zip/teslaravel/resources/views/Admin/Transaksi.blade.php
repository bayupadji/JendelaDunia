@extends('Layout.index')

@section('User')

@section('content')

    <div class="container">
        <main>
            <div class="container-fluid px-4 mt-3">
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item active">Daftar Transaksi</li>
                </ol>
            </div>
        </main>
    </div>

    <div class="container">
        <a style="font-size: 20px; " href="db"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22"
                fill="currentColor" class="bi bi-arrow-left-circle" viewBox="0 0 16 16">
                <path fill-rule="evenodd"
                    d="M1 8a7 7 0 1 0 14 0A7 7 0 0 0 1 8zm15 0A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-4.5-.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5z">
                </path>
            </svg> Back</a>
        <br>
        <a class="btn mt-3" href="">Tambah</a>

        <table class="table mt-3">
            <thead>
                <tr>
                    <th scope="col">IdBuku</th>
                    <th scope="col">IdUser</th>
                    <th scope="col">Tanggal Transaksi</th>
                    <th scope="col">Jumlah bayar</th>
                    <th scope="col">Alamat Pengiriman</th>
                    <th scope="col">Kota</th>
                    <th scope="col">Kabupaten</th>
                    <th scope="col">Provinsi</th>
                    <th scope="col">Pembayaran</th>
                    <th scope="col">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th scope="row">1</th>
                    <td>Mark</td>
                    <td>Otto</td>
                    <td>@mdo</td>
                    <td>@mdo</td>
                    <td>@mdo</td>
                    <td>@mdo</td>
                    <td>@mdo</td>
                    <td>@mdo</td>
                    <td>
                        <a href="" class="btn btn-danger ">Verifikasi</a>
                        <a href="" class="btn btn-danger mt-1">Hapus</a>
                    </td>
            </tbody>
        </table>
    </div>

@endsection
