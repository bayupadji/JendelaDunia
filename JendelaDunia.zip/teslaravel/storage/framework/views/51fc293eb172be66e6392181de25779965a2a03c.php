<?php $__env->startSection('title', 'Daftar'); ?>

<?php $__env->startSection('content'); ?>

    
    <div class="container d-flex justify-content-center">
        <div class="card cardlogin">
            <form>
                <div class="card-body bodyc ">
                    <div class="text-center">
                        <h2 class="titles">Daftar</h2>
                    </div>
                    <div class="mb-3 ">
                        <label for="exampleInputPassword1 " class="form-label loginform ">Nama</label>
                        <input type="password " class="form-control " id="exampleInputPassword1 "
                            placeholder="Masukan Nama ">
                    </div>
                    <div class="mb-3 ">
                        <label for="exampleInputPassword1 " class="form-label loginform ">Email</label>
                        <input type="password " class="form-control " id="exampleInputPassword1 "
                            placeholder="Masukan Email ">
                    </div>
                    <div class="mb-3 ">
                        <label for="exampleInputPassword1 " class="form-label loginform ">No.Telp</label>
                        <input type="password " class="form-control " id="exampleInputPassword1 "
                            placeholder="Masukan Nomor Telepon ">
                    </div>
                    <div class="mb-3 ">
                        <label for="exampleInputEmail1 " class="form-label loginform ">Username</label>
                        <input type="email " class="form-control " id="exampleInputEmail1 " aria-describedby="emailHelp "
                            placeholder="Masukan Username ">
                    </div>
                    <div class="mb-3 ">
                        <label for="exampleInputPassword1 " class="form-label loginform ">Password</label>
                        <input type="password " class="form-control " id="exampleInputPassword1 "
                            placeholder="Masukan Password ">
                    </div>
                    <div class="text-center ">
                        <button type="submit " class="btn "
                            style="margin-bottom: 10px; margin-top: 10px;padding-left: 2em;padding-right: 2em; ">Daftar</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\teslaravel\resources\views/Content/Register.blade.php ENDPATH**/ ?>